import functools

from flask import (
    Blueprint, flash, g, redirect, render_template, request, session, url_for
)
from werkzeug.security import check_password_hash, generate_password_hash

from Mensa.db import get_db
from Mensa.debug import debug

bp = Blueprint("auth", __name__, url_prefix="/auth")

def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None:
            return redirect(url_for('auth.login'))
        elif g.user['firstlogin']:
            return redirect(url_for("auth.firstlogin"))
        return view(**kwargs)

    return wrapped_view

@bp.before_app_request
def load_logged_in_user():
    user_id = session.get('user_id')



    if user_id is None:
        g.user = None
    else:
        db = get_db()
        if session.get("password") == get_db().execute('SELECT * FROM user WHERE id = ?', (user_id,)).fetchone()["password_user"]:
            g.user = get_db().execute(
                'SELECT * FROM user WHERE id = ?', (user_id,)
            ).fetchone()
        else:
            g.user = None


@bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('auth.login'))



def create_user(username: str, password: str, rights=0):
    db = get_db()
    error = None

    if not username:
        error = 'Username is required.'
    elif not password:
        error = 'Password is required.'
    if error is None:
        try:
            db.execute(
                "INSERT INTO user (username, password,password_user,rights,firstlogin) VALUES (?,?,?,?,?)",
                (username, generate_password_hash(password),generate_password_hash(generate_password_hash(password)), rights,1),
            )
            db.commit()
        except db.IntegrityError:
            error = f"User {username} is already registered."
    if not error is None:
        raise ValueError(error)
    else:
        raise ValueError(f"Succesfully created the User {username}!")


def rights_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if not g.user['rights']:
            return redirect(url_for("bestellen.menu"))
        return view(**kwargs)

    return wrapped_view

from Mensa.forms import LoginForm,ChangePasswordForm


@bp.route('/login', methods=('GET', 'POST'))
def login():
    form = LoginForm(request.form)
    if request.method == 'POST' and form.validate():
        username = form.username.data
        password = form.password.data
        db = get_db()
        error = None
        user = db.execute(
            'SELECT * FROM user WHERE username = ?', (username,)
        ).fetchone()

        if user is None or not check_password_hash(user['password'], password):
            error = 'Incorrect username or password!'

        if error is None:
            session.clear()
            session['user_id'] = user['id']
            session["user"] = username
            session["rights"] = user["rights"]
            session["password"] = user["password_user"]
            return redirect(url_for('bestellen.menu'))

        flash(error)

    return render_template('auth/login.html',form=form)

@bp.route('firstlogin', methods=('GET', 'POST'))
def firstlogin():
    form = ChangePasswordForm(request.form)
    if g.user is None:
        return redirect(url_for('auth.login'))
    if not g.user['firstlogin']:
        return redirect(url_for('bestellen.menu'))
    if request.method == "POST" and form.validate():
        password = form.password.data
        db = get_db()
        error = None
        if not password:
            error = 'Password is required.'
        password_hash = generate_password_hash(password)
        if error is None and not check_password_hash(g.user['password'],password):
            try:
                db.execute("UPDATE user SET firstlogin = 0, password = (?) ,password_user = (?) WHERE username=(?)",(password_hash,generate_password_hash(password_hash),g.user['username']),)
                db.commit()
                session["password"] = get_db().execute('SELECT * FROM user WHERE id = ?', (g.user["id"],)).fetchone()["password_user"]
                return redirect(url_for("bestellen.menu"))
            except db.IntegrityError:
                error = f"User {g.user['username']} does probably not exist."
        flash(error)

    return render_template("auth/firstlogin.html",form=form)

@bp.route('/register', methods=('GET', 'POST'))
@rights_required
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        db = get_db()
        error = None
        password_hash = generate_password_hash(password)

        if not username:
            error = 'Username is required.'
        elif not password:
            error = 'Password is required.'

        if error is None:
            try:
                db.execute(
                    "INSERT INTO user (username, password,password_user,rights) VALUES (?, ?,?)",
                    (username, generate_password_hash(password),generate_password_hash(password), 1),
                )
                db.commit()
            except db.IntegrityError:
                error = f"User {username} is already registered."
            else:
                return redirect(url_for("auth.login"))

        flash(error)

    return render_template('auth/register.html')

