import json
from datetime import datetime
from datetime import timedelta

deutsche_namen = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag"]
from flask import (
    Blueprint, flash, redirect, render_template, request, session, url_for
)
from Mensa.auth import login_required
from Mensa.auth import rights_required

from Mensa.db import get_db

bp = Blueprint("bestellen", __name__, url_prefix="/bestellen")


def weekdays(datum=None):
    if datum == None:
        date = datetime.today() + timedelta(days=7)
    else:
        date = datum
    print(date.day)

    if date.weekday() == 6:
        lst_sunday = date
    else:
        for i in range(1, 8):
            Previous_Date = date - timedelta(days=i)
            if Previous_Date.weekday() == 6:
                lst_sunday = Previous_Date
                break
    weekdays_lst = [(lst_sunday + timedelta(days=i)) for i in range(1, 6)]
    weekdays_but_better = [f"{item.day}.{item.month}.{item.year}" for item in weekdays_lst]
    lst_monday = lst_sunday + timedelta(days=1)
    return date, weekdays_lst, weekdays_but_better, lst_monday


@bp.route("/create_menu")
@login_required
@rights_required
def create_menu():
    error = None
    db = get_db()
    db.execute("DROP TABLE menus")
    db.execute("CREATE TABLE menus (menu_name TEXT PRIMARY KEY UNIQUE NOT NULL,menu_items TEXT NOT NULL);")
    menu1 = str(json.dumps({"10.10.2022": "/", "11.10.2022": "Tortellini in Sahnesauce mit\nSalat ",
                            "12.10.2022": "Frühlingsrolle mit Püree und\nMöhrensalat",
                            "13.10.2022": "Erbsensuppe mit Brötchen ", "14.10.2022": "/"}))
    menu1_name = "Vegetarisch-10.10.2022"
    menu2 = str(json.dumps(
        {"10.10.2022": "/", "11.10.2022": "/", "12.10.2022": "Hähnchenflügel mit Püree und\nMöhrensalat ",
         "13.10.2022": "Erbsensuppe mit Würstchen\nund Brötchen", "14.10.2022": "/"}))
    menu2_name = "nicht Vegetarisch-10.10.2022"
    try:
        db.execute(
            "INSERT INTO menus (menu_name, menu_items) VALUES (?, ?)",
            (menu1_name, menu1),
        )
        db.execute(
            "INSERT INTO menus (menu_name, menu_items) VALUES (?, ?)",
            (menu2_name, menu2),
        )
        db.commit()
    except db.IntegrityError:
        error = f"User {menu1} is already registered."
    return f"good {error}"


@bp.route("/menu", methods=('GET', 'POST'))
@login_required
def menu():
    db = get_db()
    Bestellungen = db.execute("SELECT * FROM Bestellungen").fetchall()
    menus = db.execute("SELECT * FROM menus").fetchall()
    for i in menus:
        print(f"row:{i}")
        for item in i:
            print(f"column:{item}")
    if not Bestellungen == None:
        menu_list = []
        for i, items in enumerate(Bestellungen):
            temp = []
            for item in items:
                temp.append(item)
                print(item)
            menu_list.append(temp)
            print(f"i:{i}")
        print(menu_list)
    if request.method == "POST":
        menu = request.json["menu"]
        menu = menu.split("-")
        date_menu = datetime.strptime(menu[1], "%d.%m.%Y")
        print(date_menu)
        print(datetime.today())
        date_delta = date_menu - datetime.strptime(datetime.today().strftime("%d.%m.%Y"), "%d.%m.%Y")
        print(date_delta.days)

        print(menu)
        menus = db.execute(
            f'SELECT * FROM Bestellungen WHERE menu_time=\'{menu[1]}\' AND username=\'{session.get("user")}\';').fetchall()

        if not menus is None and date_delta.days >= 0 and date_menu.weekday() < 6:
            for i in menus:
                print(i)
            print("////")
            db.execute(
                f'DELETE FROM Bestellungen WHERE menu_time=\'{menu[1]}\' AND username=\'{session.get("user")}\';')
            db.commit()
            db.execute(f"INSERT INTO Bestellungen (username,menu_name,menu_time) VALUES(?,?,?)",
                       (session.get("user"), menu[0], menu[1]))
            db.commit()
            return (f"Du hast {menu[0]} für den {menu[1]} bestellt!")
        return (f"ERROR THATS NOT A VALID DAY!")
    (date, weekdays_lst, weekdays_str, monday) = weekdays()
    monday = f"{monday.day}.{monday.month}.{monday.year}"
    menu_veg_name = f"Vegetarisch-{monday}"
    print(f"menu:{menu_veg_name}")
    menu_nichtveg_name = f"nicht Vegetarisch-{monday}"
    menu_veg_sql = db.execute(
        'SELECT * FROM menus WHERE menu_name = ?', (menu_veg_name,)
    ).fetchone()
    menu_nichtveg_sql = db.execute(
        'SELECT * FROM menus WHERE menu_name = ?', (menu_nichtveg_name,)
    ).fetchone()
    print("sus")
    if not menu_nichtveg_sql is None:
        print(menu_nichtveg_sql["menu_items"])
    if not menu_nichtveg_sql == None and not menu_veg_sql == None:
        menu_veg = menu_veg_sql["menu_items"]
        print(type(menu_veg))
        menu_veg = json.loads(menu_veg)

        # menu_veg = json.loads(menu_veg_sql["menu_items"])
        menu_nichtveg = json.loads(menu_nichtveg_sql["menu_items"])
        print(menu_nichtveg)
    elif not menu_nichtveg_sql == None and menu_veg_sql == None:
        menu_veg = json.loads(menu_veg_sql["menu_items"])
        menu_nichtveg = {}
        for item in weekdays_str:
            menu_nichtveg[item] = "/"
    elif not menu_veg_sql == None and menu_nichtveg_sql == None:
        menu_nichtveg = json.loads(menu_nichtveg_sql["menu_items"])
        menu_veg = {}
        for item in weekdays_str:
            menu_veg[item] = "/"
    else:
        menu_veg = {}
        menu_nichtveg = {}
        for item in weekdays_str:
            menu_veg[item] = "/"
            menu_nichtveg[item] = "/"
    date = datetime.today().weekday()
    temp = {}
    for i, items in enumerate(menu_veg.items()):
        key, item = items
        if item == "/":
            temp[key] = ["false", item]
        elif i >= date:
            temp[key] = ["true", item]
        else:
            temp[key] = ["false", item]
    menu_veg = temp
    temp = {}
    for i, items in enumerate(menu_nichtveg.items()):
        key, item = items
        if item == "/":
            temp[key] = ["false", item]
        elif i >= date:
            temp[key] = ["true", item]
        else:
            temp[key] = ["false", item]
    menu_nichtveg = temp

    return render_template("bestellen/bestellen.html", weekdays_str=weekdays_str,
                           weekdays_name=deutsche_namen, veg=menu_veg, nichtveg=menu_nichtveg)


@bp.route("/create", methods=["GET", "POST"])
@login_required
@rights_required
def datum_create():
    if request.method == "POST":
        datum = request.form["Monday"]
        error = ""
        try:
            date = datetime.strptime(datum, '%d.%m.%Y').weekday()
        except:

            date = 9
        if date == 0:
            db = get_db()
            exists = db.execute(f"SELECT * FROM menus WHERE menu_name='Vegetarisch-{datum}'").fetchone()
            if not exists:
                return redirect(url_for("bestellen.create", datum=datum))
            else:
                flash("This menu is already created!")
        else:
            flash("Please enter a valid date for a monday and use the format: %d.%m.%Y (for example 17.10.2022)")
    return render_template("bestellen/bestellen_create_datum.html")


@bp.route("/create/<datum>", methods=["GET", "POST"])
@login_required
@rights_required
def create(datum):
    datum_real = datum
    datum = datetime.strptime(datum, "%d.%m.%Y")
    (date, weekdays_lst, weekdays_str, monday) = weekdays(datum)
    db = get_db()
    exists = db.execute(f"SELECT * FROM menus WHERE menu_name='Vegetarisch-{datum}'").fetchone()
    if not exists == None:
        return redirect(url_for("bestellen.datum_create"))
    Vegetarisch = {}
    nichtVegetarisch = {}
    if request.method == "POST":
        print("good")
        for item in request.form:
            print(f"item:{item}")
            key = item.split("-")
            print(f"key:{key}")
            if key[0] == "Vegetarisch":
                if request.form[item] == "":
                    form = "/"
                else:
                    form = request.form[item]
                Vegetarisch[item] = form
            if key[0] == "nichtVegetarisch":
                if request.form[item] == "":
                    form = "/"
                else:
                    form = request.form[item]
                nichtVegetarisch[f"nicht Vegetarisch-{key[1]}"] = form

        Vegetarisch = str(json.dumps(Vegetarisch))
        print(Vegetarisch)
        nichtVegetarisch = str(json.dumps(nichtVegetarisch))
        print(nichtVegetarisch)
        date = f"{date.day}.{date.month}.{date.year}"
        Vegetarisch_name = f"Vegetarisch-{datum_real}"
        print(Vegetarisch_name)
        nichtVegetarisch_name = f"nicht Vegetarisch-{datum_real}"
        try:
            db.execute(
                "INSERT INTO menus (menu_name, menu_items) VALUES (?, ?)",
                (Vegetarisch_name, Vegetarisch),
            )
            db.commit()
            db.execute(
                "INSERT INTO menus (menu_name, menu_items) VALUES (?, ?)",
                (nichtVegetarisch_name, nichtVegetarisch),
            )
            db.commit()
        except db.IntegrityError:
            error = f"The menu for the {datum_real} is already created"
            flash(error)

    return render_template("bestellen/bestellen_create.html", weekdays_str=weekdays_str, weekdays_name=deutsche_namen)
