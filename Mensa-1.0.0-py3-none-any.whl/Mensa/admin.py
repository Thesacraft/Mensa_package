import csv
import os

from flask import (
    Blueprint, flash, render_template, request, current_app
)

from Mensa.auth import create_user
from Mensa.auth import login_required
from Mensa.auth import rights_required
from Mensa.db import get_db

bp = Blueprint("admin", __name__)


@bp.route("/admin", methods=["GET", "POST"])
@login_required
@rights_required
def admin_site():
    db = get_db()
    data = []
    users_db = db.execute("SELECT * FROM user").fetchall()
    users = [item[1] for item in users_db]

    if request.method == 'POST':
        if request.files and request.files['filename'].filename:
            uploaded_file = request.files['filename']  # This line uses the same variable and worked fine
            print(current_app.config["FILE_UPLOADS"])
            filepath = os.path.join(current_app.config['FILE_UPLOADS'], uploaded_file.filename)
            print(filepath)
            uploaded_file.save(filepath)
            with open(filepath) as file:
                csv_file = csv.reader(file)
                for row in csv_file:
                    data.append(row)
            with open(filepath, "r") as fh:
                fb = fh.read()
            for item in data:
                if len(item) <= 2 and len(item) > 0:
                    try:
                        create_user(username=item[0], password=item[1])
                    except ValueError as err:
                        flash(err)
                else:
                    flash(f"too many arguements for a user! You can only specify the username and Password")
            print(type(fb))
            print(data)
            os.remove(filepath)
        else:
            flash("No file found!")
    return render_template('admin/admin_site.html', data=data, users=users)
