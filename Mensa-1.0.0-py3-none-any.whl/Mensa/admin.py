import csv
import os
from collections import OrderedDict
from datetime import datetime

from flask import (
    Blueprint, flash, render_template, request, current_app
)

from Mensa.auth import create_user
from Mensa.auth import login_required
from Mensa.auth import rights_required
from Mensa.db import get_db

bp = Blueprint("admin", __name__)

"""
This Creates the admin site 
The admin site is supposed to give the admins the functionality to add users and See them
"""
@bp.route("/admin", methods=["GET", "POST"])
@login_required
@rights_required
def admin_site():
    db = get_db()
    data = []
    users_db = db.execute("SELECT * FROM user").fetchall()
    users = [item[1] for item in users_db]

    if request.method == 'POST':
        if request.files and request.files['filename'].filename:
            uploaded_file = request.files['filename']  # This line uses the same variable and worked fine
            filepath = os.path.join(current_app.config['FILE_UPLOADS'], uploaded_file.filename)
            uploaded_file.save(filepath)
            with open(filepath) as file:
                csv_file = csv.reader(file)
                for row in csv_file:
                    data.append(row)
            with open(filepath, "r") as fh:
                fb = fh.read()
            for item in data:
                if len(item) <= 2 and len(item) > 0:
                    try:
                        create_user(username=item[0], password=item[1])
                    except ValueError as err:
                        flash(err)
                else:
                    flash(f"too many arguements for a user! You can only specify the username and Password")
            os.remove(filepath)
        else:
            flash("No file found!")
    return render_template('admin/admin_site.html', data=data, users=users)

"""
This Creates the bestellungen site (in english: Orders site)
The site is supposed to give the admins the functionality to see who ordered what for the day
"""
@bp.route("/bestellungen")
@login_required
@rights_required
def bestellungen():
    """
    this is getting the Orders and then formatting them to look good on the website and changes the dict to be ordered by the days
    """
    db = get_db()
    Bestellungen_temp = db.execute("SELECT * FROM Bestellungen").fetchall()
    Bestellungen_temp2 = {}
    for item in Bestellungen_temp:
        if not item[-1] in Bestellungen_temp2.keys():
            Bestellungen_temp2[item[-1]] = {"Vegetarisch": [], "nicht Vegetarisch": []}
        Bestellungen_temp2[item[-1]][item[2]].append(item[1])
    Bestellungen = {}

    for day, item in Bestellungen_temp2.items():
        temp = {}
        for menutype, users in item.items():
            if len(users) == 0:
                user = ["/"]
            else:
                user = users
            temp[f"{menutype} ({len(users)})"] = user
        Bestellungen[day] = temp
    Bestellungen = OrderedDict(
        sorted(Bestellungen.items(), key=lambda x: datetime.strptime(x[0], '%d.%m.%Y')))
    return render_template("admin/Bestellungen.html", Bestellungen=Bestellungen)
