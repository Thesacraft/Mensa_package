from wtforms import Form, StringField, PasswordField, validators


class LoginForm(Form):
    username = StringField("Username",[validators.Length(max=30)])
    password = PasswordField('Password',[
        validators.DataRequired(),
    ])

class ChangePasswordForm(Form):
    password = PasswordField('New Password',[
        validators.Length(min=4,max=30),
        validators.DataRequired(),
        validators.EqualTo('confirm', message='The passwords dont match!')
    ])
    confirm = PasswordField('Repeat the Password')
