from wtforms import Form, StringField, PasswordField, validators
import wtforms

class LoginForm(Form):
    username = StringField("Username",[validators.Length(max=30)])
    password = PasswordField('Password',[
        validators.DataRequired(),
    ])

class ChangePasswordForm(Form):
    password = PasswordField('New Password',[
        validators.Length(min=4,max=30),
        validators.DataRequired(),
        validators.EqualTo('confirm', message='The passwords dont match!')
    ])
    confirm = PasswordField('Repeat the Password')

class RegisterForm(Form):
    username = StringField("Username",[validators.Length(max=30),validators.DataRequired()])
    password = PasswordField('Password', [
        validators.Length(min=4, max=30),
        validators.DataRequired(),
        validators.EqualTo('confirm', message='The passwords dont match!')
    ])
    confirm = PasswordField('Repeat the Password')
    rights = wtforms.BooleanField("Admin Rights")
