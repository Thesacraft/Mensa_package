import functools
from flask import redirect,url_for,app

def debug(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if not app.get_debug_flag():
            return redirect(url_for('auth.login'))
        return view(**kwargs)
    return wrapped_view