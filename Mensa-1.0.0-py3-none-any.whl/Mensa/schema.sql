DROP TABLE IF EXISTS user;
DROP TABLE IF EXISTS menus;
DROP TABLE IF EXISTS Bestellungen;


CREATE TABLE user (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  rights INT NOT NULL,
  firstlogin INT NOT NULL
);

CREATE TABLE menus (
  menu_name TEXT PRIMARY KEY UNIQUE NOT NULL,
  menu_items TEXT NOT NULL
);

CREATE TABLE Bestellungen (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL,
  menu_name TEXT NOT NULL,
  menu_time TEXT NOT NULL
);